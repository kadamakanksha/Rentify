const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Property = require('../models/Property');

// Post a property
router.post('/', auth, async(req, res) => {
    const { location, area, bedrooms, bathrooms, price, description, amenities } = req.body;
    try {
        const newProperty = new Property({
            user: req.user.id,
            location,
            area,
            bedrooms,
            bathrooms,
            price,
            description,
            amenities
        });

        const property = await newProperty.save();
        res.json(property);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

// Get all properties
router.get('/', async(req, res) => {
    try {
        const properties = await Property.find().populate('user', ['firstName', 'lastName', 'email', 'phone']);
        res.json(properties);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

// Get properties by user
router.get('/my-properties', auth, async(req, res) => {
    try {
        const properties = await Property.find({ user: req.user.id });
        res.json(properties);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

// Delete property
router.delete('/:id', auth, async(req, res) => {
    try {
        const property = await Property.findById(req.params.id);

        if (!property) {
            return res.status(404).json({ msg: 'Property not found' });
        }

        if (property.user.toString() !== req.user.id) {
            return res.status(401).json({ msg: 'User not authorized' });
        }

        await property.remove();
        res.json({ msg: 'Property removed' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

module.exports = router;
const jwt = require('jsonwebtoken');

module.exports = function(req, res, next) {
    const token = req.header('x-auth-token');

    if (!token) {
        return res.status(401).json({ msg: 'No token, authorization denied' });
    }

    try {
        const decoded = jwt.verify(token, 'your_jwt_secret');
        req.user = decoded.user;
        next();
    } catch (err) {
        res.status(401).json({ msg: 'Token is not valid' });
    }
};